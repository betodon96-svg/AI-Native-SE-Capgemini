---
name: create-dev-log-entry
description: Append an entry to the dev log summarizing a work session — what was done, by which skills, what it cost, what was decided, what is queued next. Use at the end of every work session, so a future session or reviewer with no shared context can pick up.
---

Read [`CONVENTIONS.md`](../../../CONVENTIONS.md) §6 (logging and rationale) before writing.

## Writing the entry

Append to `logs/dev-log.md`, **newest first**, never editing or removing a prior entry. Write for a
reader who has none of this session's conversational context, who has only this entry and what it
links to. Each entry records:

- **Date.**
- **What was worked on**, in plain terms. Not a transcript, but a summary someone can skim in thirty
  seconds and understand what happened and why it mattered.
- **Which skills ran**, and for each: **what it cost** (elapsed time, tokens or tool calls where
  available, errors) and **how it performed**. A correct artifact is not evidence of a sound skill
  (§8). If a skill produced something unusable, or needed working around, say so here and change the
  skill.
- **Which artifacts and IDs** were created, modified or reviewed, and the commit SHAs where code
  changed.
- **Decisions made in session**, by pointer. A ruling by the owner goes to `DECISION_LOG.md`, a
  defect to `logs/bug-change-log.md`, and a requirement change to that requirement's revision
  history. Point at those entries by ID; do not duplicate them here.
- **Open loops**: reviews whose findings are not yet re-reviewed, items transmitted upstream, anything
  declared unchecked.
- **What is queued next**, so a future session with no memory of this one knows where to pick up.
