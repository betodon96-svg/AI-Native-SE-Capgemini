---
name: modify-architecture-doc
description: Apply a change to an existing architecture document — a design change, a new or changed requirement driving a component change, a review finding, or a diagram that has drifted from the prose or the code — under the whole-document coherence obligation. Use when the architecture document already exists.
---

You are changing an **existing** architecture document. If none exists, use
`create-architecture-doc`.

## Before you start

1. Read [`CONVENTIONS.md`](../../../CONVENTIONS.md): §5 (change control), §6 (logging), §9
   (diagramming).
2. Identify what is driving the change. It is one of: a new or changed requirement or use case (cite
   its ID and revision), a design flaw found during implementation, a constraint the owner added, a
   review finding (cite the `logs/eval-log.md` entry), or a diagram that has drifted from what the
   prose or the code actually says.
3. If the trigger is a corrected requirement or a corrected source extraction, **every conclusion this
   document drew from the uncorrected version is stale** (§3). List them and re-derive each; do not
   only patch the one that prompted the change.
4. Identify **every diagram and every `MODULE-x` reference affected.** A change to one component's
   responsibilities usually means the component view, at least one sequence or state view, the
   coverage matrix and the prose all have to move together. Check all of them. Do not update one and
   leave the others stale.

## The whole-document coherence obligation

The architecture document is **Pattern B** (§5): a single coherent statement whose sections must agree
with each other, not a register of independent items. It is **edited in place**, with no archive
copies and no numbered files, because git already holds every prior state.

What Pattern B adds over an ordinary edit is one obligation. Rewrite the **"Changed since v(n−1)"**
section, recording:

- **What changed and why**, citing the triggering requirement, use case, decision or finding by ID,
  and a commit SHA where it traces to existing code.
- **What you checked for consistency and found still valid.** This is the part that earns the
  pattern, and the one thing git cannot supply: a diff shows what changed, never what you examined and
  confirmed still correct. In a document whose sections must agree, changing one can silently
  invalidate another, so **name the sections you verified against this change, not only the ones you
  edited.**
- **Anything you could not verify**, named explicitly rather than left silent.

Then bump the version in the revision history.

Requirements, use cases and eval sets are Pattern A: append-only per item, with no whole-document
coherence claim. **Do not apply this obligation to those.**

## Making the change

1. Append a revision entry: date, author, what changed, and why, citing the trigger by ID and a
   commit SHA if it traces to code that exists.
2. **Update every affected diagram in the same change.** A prose-only update that leaves a diagram
   describing the old design is worse than no diagram, because it actively misleads rather than
   merely omitting. **Re-render every diagram you touch** and check it against the pitfalls in §9.
3. **Regenerate the coverage matrix** for every requirement whose owning component changed, and
   re-state gaps, unexplained scope and weakened requirements.
4. If the change is more than a clarification, **reset `status` to `draft`** and reapply
   `[PRELIMINARY]`, because it needs to clear review again.
5. **Preserve the stakeholder-facing / developer-facing split** (§9). If a change makes a
   stakeholder-facing view harder for a non-technical reader, the detail belongs in a developer-facing
   view; that is not a reason to abandon the split.
6. **Point, never restate.** If a section here repeats content owned by another artifact (open items
   owned by the requirements document, module status owned by the roadmap, requirement text owned by
   a `REQ-nnn`), replace the restatement with a pointer to the owning document and ID. **Restated
   content is what goes stale**, and a copy that is accurate today is still a defect, because nothing
   keeps it accurate (§5).

## After the change

1. If the trigger was a design flaw found during implementation, record it via
   `create-bug-log-entry`.
2. Log the session via `create-dev-log-entry`: what changed, what you verified as still valid, and
   what you could not verify.
3. Flag that the modified sections need another `review-architecture-doc` pass, scoped to the change,
   before status advances past `draft`, unless it was a pure clarification.
