---
name: create-use-case-doc
description: Draft the initial use-case document, describing end-to-end interaction flows that satisfy specific requirements, each traceable to REQ-nnn IDs. Use when no use-case document exists yet and a first, clearly preliminary draft is needed.
---

You are drafting the **first version** of this project's use-case document. This skill is
domain-agnostic. All project-specific content (the requirements, the actors, the workflows) comes from
the repository's own documents, which you must read before writing anything.

## Before you start

1. Read [`CONVENTIONS.md`](../../../CONVENTIONS.md): traceability (§2), status and marking (§4),
   change control (§5).
2. Read the requirements document in full, including its open items. A use-case document describes
   *how* requirements are satisfied end to end (who does what, in what order, producing what output).
   It does not restate requirement text; it references `REQ-nnn` IDs.
3. Check whether `use-cases/` already holds a use-case document. If it does, use `modify-use-case-doc`
   instead. This skill is for the first draft only.
4. If the requirements document is itself still entirely preliminary, say that you are drafting
   against unstable ground and mark the whole use-case document `[PRELIMINARY]` accordingly. A
   parallel first pass is fine if the owner wants one, but be explicit about the dependency.

## Drafting

1. Identify the actors (people in roles, external systems, physical devices, authorities) from the
   requirements and supporting source material. **Do not invent actors the material does not
   support.**
2. For each significant end-to-end flow, write a use case with: preconditions, the step-by-step main
   flow, postconditions and outputs, and exception and edge-case handling. Exceptions are where
   requirements are most often under-specified, so do not skip them.
3. Link every step, or the use case as a whole, to the `REQ-nnn` IDs it satisfies. **A use case with
   no linked requirement means either a requirement is missing** (add it to the requirements open
   items via `modify-requirements-doc`) **or the use case is out of scope.**
4. Give each use case a stable `UC-nnn` ID (three digits, zero-padded, sequential, never reused),
   `status: draft`, and a revision history with a first entry: date, author (AI-drafted), rationale
   ("initial draft from requirements").
5. Use the requirements' vocabulary. Do not introduce a second name for a concept that already has
   one.
6. Mark content `[PRELIMINARY]` at the point of the claim (§4). Flag ambiguities (an unclear actor
   responsibility, an edge case the requirements do not address) **inline** rather than resolving
   them silently, and transmit any that need a decision to the requirements open items.

## After drafting

1. Log the session via `create-dev-log-entry`: which flows you drafted, requirements with no use case
   and use cases with no requirement, anything transmitted upstream, and what the run cost.
2. This document goes through `review-use-case-doc` in a fresh session before status can advance. **Do
   not mark anything `reviewed` or `approved` yourself** as the drafting agent.
