---
name: create-requirements-doc
description: Draft the initial requirements document from the project's source obligations, deriving REQ-nnn requirements traceable to specific SRC-x.y clauses. Use when no requirements document exists yet and a first, clearly preliminary draft is needed.
---

You are drafting the **first version** of this project's requirements document from its source
obligations. This skill is domain-agnostic. All project-specific content comes from the repository's
own documents, which you must read before writing anything.

## Before you start

1. Read [`CONVENTIONS.md`](../../../CONVENTIONS.md): traceability (§2), sources and intermediates
   (§3), status and marking (§4), change control (§5). Follow it exactly. Do not invent a variant.
2. Read the non-negotiable constraints in [`CLAUDE.md`](../../../CLAUDE.md). A requirement that
   implicitly violates one is wrong however well it is written; one example is a requirement that
   implies runtime model inference in a project that has ruled it out.
3. Locate the machine-readable source extractions in `sources/`, plus any supporting notes. **If the
   source text is not present, stop and say so.** Do not draft requirements from recollection of
   what a source probably says.
4. Read each extraction's **"could not extract" block**. If a lost table, figure or formula carries
   obligations, **send it back to be fixed in the extraction**, and do not read the original yourself
   (§3). If that cannot be done now, list the affected clauses as unchecked in the document's
   provenance block.
5. Check whether `requirements/` already holds a requirements document. If it does, this is the wrong
   skill: use `modify-requirements-doc`. This one is for the first draft only.

## Drafting

1. **Open the document with a provenance block** (§2): which source extractions it derives from and
   at what revision, what feeds on it, *not generated*, and any clauses declared unchecked at step 4.
2. Work through each source systematically, section by section. For every clause that imposes an
   obligation on the system, assign it a `SRC-x.y` ID **matching the source's own numbering**.
   Examples of such clauses: a record to keep, a field to submit, a check to perform, a timing or
   tolerance, a retention period, an access control.
3. For each `SRC-x.y`, or a small cluster of genuinely related clauses, derive one `REQ-nnn`: a
   specific, testable statement of what the system must do to satisfy it. Prefer one clear
   requirement over one vague requirement covering several clauses, but do not split a single
   obligation into redundant duplicates either.
4. Number `REQ-nnn` sequentially, three digits, zero-padded. **Never reuse or reorder an ID.**
5. Every entry carries, at minimum:
   - the `REQ-nnn` ID;
   - the requirement text;
   - the `SRC-x.y` clause or clauses it derives from;
   - `status: draft`;
   - a revision history with one first entry: date, author (AI-drafted), rationale ("initial draft
     from source obligations").
6. **Use the source's vocabulary.** Do not invent a second name for a concept the source already
   names. A second name for one thing is how two entries get created for it and never converge.
7. If the owner has said a scope area is deferred, **still record it** as a requirement with a
   deferred marker. Do not silently drop it. Defer only what you were explicitly told is deferred;
   do not invent deferrals.
8. Mark the document and **every individual entry** `[PRELIMINARY]` at the point of the claim (§4).
9. **Where the source is ambiguous, contradictory, or silent on something the system will have to
   handle, do not guess silently.** Flag it inline as
   `[PRELIMINARY — ambiguous: the source does not specify X]`, and add it to the document's
   **open-items section** as a `REQ-nnn` stating what is unknown, what it blocks and who must resolve
   it (§2).

## Writing a requirement that can actually be checked

A requirement whose satisfaction cannot be established is an intention, not a requirement. As you
write each one, ask what an `EVAL-nnn` against it would assert. If you cannot answer, the requirement
is too vague. Say so inline rather than leaving it for the reviewer to discover. **An unbound
quantity, an undefined constant or an unmeasurable adjective makes a requirement unverifiable.**

## After drafting

1. Log the session via `create-dev-log-entry`: what you drafted, how many requirements, which source
   sections you covered, **anything you could not cover and why**, and what the run cost.
2. Tell the owner the draft must go through `review-requirements-doc`, **in a fresh session**, before
   any requirement's status can move past `draft`.
3. **Do not mark anything `reviewed` or `approved`.** As the drafting agent you cannot. Only an
   independent pass followed by the owner's decision can advance status (§4, §7).
