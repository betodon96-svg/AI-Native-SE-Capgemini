---
name: update-roadmap
description: Update the existing roadmap in place — move a module between Now/Next/Later, change its review state, unblock a Later item, revise a milestone's success definition — and record why. Use at the start of a work session or whenever a module's status genuinely changes, never for the first draft.
---

You are updating an **existing** roadmap. If none exists, use `create-roadmap`.

## Before you start

1. Read the current roadmap in full. Do not assume you remember its state, because it is meant to
   change between sessions.
2. Identify exactly what changed and why. One of these happened: a module finished or entered review;
   a module started; an open item was resolved, so a Later module may now move to Next; a new blocker
   appeared; or a milestone's definition itself changed. The last is rare, and is the one to treat
   most carefully, because it redefines what "done" means for everyone reading the roadmap.

## Making the update

1. **Edit the placement and review state in place.** The roadmap is a Pattern B living statement
   ([`CONVENTIONS.md`](../../../CONVENTIONS.md) §5). Its buckets describe *now*, not a record of the
   past, so in-place editing is correct here.
2. **Append a revision-history row** stating what moved and why. A roadmap that changes with no record
   of *why* priorities shifted is exactly the audit gap the conventions exist to prevent. The bucket
   contents change in place; the reasoning trail does not.
3. If a module moves from Later to Next because a blocking item was resolved, **cite the resolution**:
   the `REQ-nnn`, the `DECISION_LOG.md` entry, the commit. Do not move it silently.
4. **A module does not leave "pending review"** until a review pass returned nothing material and the
   owner accepted it. Cite the `logs/eval-log.md` entry.
5. If a milestone's success definition changes, make that **as prominent as any change in the
   document**, since everything else in the roadmap is organized relative to it.
6. **Point, never restate.** If you are tempted to explain *why* a module is blocked in detail, that
   explanation belongs in the requirements open items or an `open-questions/` dossier. The roadmap
   points to the ID.

## After updating

1. Re-run the consistency check from `create-roadmap`: every module appears once, every blocker cites
   an open `REQ-nnn` that exists, and no Next depends on a Later.
2. If the update is substantial (a milestone definition changed, a module was dropped), flag it to the
   owner explicitly rather than letting it pass as a routine bucket shuffle.
