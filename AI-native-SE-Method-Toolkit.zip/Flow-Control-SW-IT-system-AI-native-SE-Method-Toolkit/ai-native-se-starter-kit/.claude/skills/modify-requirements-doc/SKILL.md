---
name: modify-requirements-doc
description: Apply a change to one or more existing requirements — a defect fix, a corrected reading of the source, a negotiated compromise, a scope cut, a review finding, or a new open item transmitted upstream. Use when the requirements document already exists, never for the first draft.
---

You are changing an **existing** requirements document. If none exists, stop and use
`create-requirements-doc`.

## Before you start

1. Read [`CONVENTIONS.md`](../../../CONVENTIONS.md), particularly §5 (change control) and §6
   (logging). The core rule is that **a requirement is never silently edited away or overwritten.**
   The requirements document is a Pattern A register: every change appends a new dated revision with
   rationale, and the prior revision stays in the history as the record of what was true when.
2. Identify exactly which `REQ-nnn` IDs are affected. If the change also affects the use-case
   document, the architecture or an eval set that references those IDs, **note it.** Those need
   their own follow-up changes through their own `modify-…` skills; this skill does not make them.
3. Determine the trigger. It is one of: a defect found in use, a corrected reading of the source, a
   compromise agreed with a stakeholder, a deliberate scope cut, a review finding (cite the
   `logs/eval-log.md` entry), or an open item transmitted from another skill. You need it for the
   rationale. **Do not proceed without knowing which it is.**

## Making the change

1. Append a new revision entry to each affected requirement: date, author, what changed (old text →
   new text, or old status → new status), and **why**. Reference other artifacts by ID and code by
   commit SHA rather than pasting their content (§2, §6).
2. **If the change alters meaning rather than wording, reset `status` to `draft`** and reapply
   `[PRELIMINARY]`, because a changed requirement has to clear review again. A pure clarification
   that does not change what is required may keep its status, but only if the owner confirms it is
   one.
3. **Adding an open item** (an unresolved question, a missing input, a decision someone must make):
   add a `REQ-nnn` to the open-items section stating what is unknown, what it blocks and who must
   resolve it. If the analysis needs more than a few lines, write a dossier in `open-questions/` and
   point to it. **Closing an open item** happens here, at its source, with the resolution cited,
   never only by removing references to it elsewhere.
4. **Do not touch any other requirement** while making this change, even if you notice something
   else that looks wrong. Log it separately or raise it with the owner. Bundled unrelated edits are
   unreviewable.
5. If the change warrants a new named baseline, **say so. Do not cut one.** Baselining is a
   deliberate, named act by the owner (§5).

## After the change

1. If the trigger was a defect, record it via `create-bug-log-entry`, with enough detail that the
   failure mode is recoverable later and not just the fix.
2. Log the session via `create-dev-log-entry`: which IDs changed, the trigger, and what you
   deliberately left alone.
3. If an open item was added or resolved, the affected module's roadmap entry needs updating via
   `update-roadmap`, by pointing to the ID and not restating it.
4. Point out that the modified requirement needs another `review-requirements-doc` pass before its
   status can advance past `draft`, unless step 2 established it was a pure clarification. **A fix
   is written on the assumption that the reviewer already found everything, and that assumption is
   exactly what lets a fix introduce a new defect** (§7.4).
