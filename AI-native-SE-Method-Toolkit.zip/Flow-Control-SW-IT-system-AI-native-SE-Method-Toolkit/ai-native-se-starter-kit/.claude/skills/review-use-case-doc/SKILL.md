---
name: review-use-case-doc
description: Independently validate a drafted or modified use case against the requirements document, using regenerate-and-diff rather than critique-in-place, before it can move from draft to reviewed. Use as the review gate any time a use-case entry is drafted or modified.
---

You are the **independent reviewer, not the author.** Run this in a fresh session with no shared
context from whichever session drafted or modified the use case. If you were part of that
conversation, ask to be invoked fresh ([`CONVENTIONS.md`](../../../CONVENTIONS.md) §7.3).

## Method: regenerate-and-diff, not critique-in-place

The requirements are a separable obligation the use cases derive from, so re-derivation is the right
tactic (§7.2). If the requirements a use case cites are too thin to determine its flow, say so in the
log rather than reporting the gaps of an underinformed derivation as defects.

1. Read `CONVENTIONS.md`: traceability (§2), status and marking (§4).
2. **Pin the revision** you are reviewing (§7.4).
3. Read the `REQ-nnn` requirements the use case claims to satisfy, **directly from the requirements
   document**, not from the use case's own account of them. Where a requirement's wording is
   ambiguous, read the `SRC-x.y` extraction it cites.
4. **Before reading the drafted use case**, write your own sketch to `intermediary/`: the actors, the
   steps, the preconditions, the postconditions, and the exception handling an end-to-end flow
   satisfying those requirements would need.
5. **Now** read the drafted or modified use case and diff it against your sketch. Look for:
   - **Missing exception or edge-case handling** that the requirements imply. This is the absence
     class, so look for it first.
   - Steps that do not actually satisfy the requirement they claim to.
   - Actors or responsibilities invented without support in the requirements or sources.
   - Untraceable claims: a link to the wrong `REQ-nnn`, or a missing link that should be there.
   - Restated requirement text where an ID reference belongs (§5).
6. Check structure (Tier 0, §7.1): stable ID, status field, `[PRELIMINARY]` where due, and revision
   history present and non-destructive.

## Recording the outcome — including when you find nothing

- **Report, do not repair.** List discrepancies concretely: what you derived, what the draft says, and
  why they differ. Route the fix through `modify-use-case-doc`, and route anything that is really a
  requirements problem upstream via `modify-requirements-doc`. Say which is which.
- Log the pass via `create-eval-log-entry`: the pinned revision, the `UC-nnn` IDs checked, the
  independence line (fresh context, sketch written first), the findings or **explicitly that there
  were none**, the checks not run, and the cost.
- If there are no material discrepancies, flag to the owner that the use case is **eligible** for
  `status: reviewed`. You do not set it.
