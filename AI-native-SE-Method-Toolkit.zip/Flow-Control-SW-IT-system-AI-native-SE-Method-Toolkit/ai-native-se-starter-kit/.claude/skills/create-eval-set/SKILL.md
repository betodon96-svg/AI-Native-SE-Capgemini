---
name: create-eval-set
description: Specify, then implement, the deterministic eval cases (EVAL-nnn) for a module's requirements — one or more per requirement — forming the permanent regression suite. Use when a requirement has no eval cases yet, and invoke it BEFORE writing the module's implementation, not after.
---

You are specifying the **deterministic eval cases** that run against the actual implementation, on
every change, forever. This skill is domain-agnostic. What the system does comes from the
requirements and use-case documents, not from this file.

## When this runs

**Before the implementation, not after it.** This is not a matter of style. Eval cases written after
the code are shaped by what the code happens to do and by what was convenient to test. Such a set can
look thorough while containing holes that no amount of reading it back will reveal, because you cannot
notice an absent test by inspecting the tests that exist.

If you are about to implement a module and no eval-set specification exists for its requirements,
**stop and run this first.** When this ordering fails in practice, the cause is usually not
forgetfulness. It is that nothing invoked this skill. The sequence in
[`CLAUDE.md`](../../../CLAUDE.md) exists to invoke it.

## Before you start

1. Read [`CONVENTIONS.md`](../../../CONVENTIONS.md): traceability (§2). An `EVAL-nnn` case shares
   its number with its parent `REQ-nnn`, with a lowercase suffix when a requirement needs more than
   one case (`REQ-014` → `EVAL-014a`, `EVAL-014b`).
2. Read the `REQ-nnn` requirements you are writing cases for **directly from the requirements
   document**, plus the relevant use case if one exists, since a requirement is often best tested
   through the flow described there.
3. Only specify cases for requirements that are at least `status: draft` and reasonably stable. If a
   requirement is still ambiguous or flagged, note that the case depends on its resolution rather
   than guessing at the resolution.

## Step 1 — Specify the cases before implementing any of them

Write the specification table **first**, in the eval-set document in `evals/eval-sets/`, with no test
code yet. This step is cheap and it is the whole point of the skill: it forces you to enumerate what
*should* be checked while you still know only the requirement, not the implementation.

| Column | Content |
|---|---|
| `EVAL ID` | Per the conventions scheme |
| `REQ-nnn` | Parent requirement or requirements |
| Checks | One plain sentence: what this case establishes |
| Input | Concrete, specific values or state. Not "a valid record", but the actual record |
| Expected | The concrete expected output, state change or raised error, **including side effects** (records written, alarms raised, fields set) |
| `MODULE-x` | Which module the case exercises, or "not yet assigned" |

**Coverage obligations: check each explicitly, and state in the document that you did.**

1. **Clause enumeration.** Break the requirement into its distinct clauses and conditions, and map
   every clause to at least one case. A requirement listing four independent triggers needs four
   cases, not one that happens to fire.
2. **The normal satisfying case.**
3. **Boundary conditions the requirement implies**, tested *at* the boundary and not comfortably
   either side of it. Where a requirement names a percentage, a duration or a count, the boundary case
   is mandatory. Interpretation errors hide there: two plausible readings of a source produce nearly
   identical results everywhere *except* at the boundary.
4. **At least one case that should fail the requirement**, proving the test is not vacuous.
5. **Absence and null states.** Where the requirement implies a distinction between "checked and
   fine", "checked and wrong" and "not checkable", a case must establish it. Collapsing the third into
   the first is a recurring defect class (`CONVENTIONS.md` §4).

Write cases so they are mechanically checkable: a test runner executes the case and gets pass or fail
without interpreting intent.

## Step 2 — Fixtures and synthetic data

State which fixture each case runs against. Prefer the project's shared synthetic dataset, where one
exists, over per-test inline fixtures. Inline fixtures make each test readable but give no
cross-module integration coverage, and a realistic shared dataset is usually needed for demonstration
work anyway. Where a case genuinely needs a hand-built edge-case fixture (a state impossible in
practice, a specific boundary value), build it inline and say why.

If the shared dataset needs extending to support a case, extend it. Do not quietly fall back to an
inline fixture that hides the gap.

## Step 3 — Implement

Now write the test code. The eval-set document is the traceability index and specification, and the
tests are the executable artifact. Neither duplicates the other's content.

If, while implementing, you find that a case in the specification cannot be written as specified,
**state that in the document and say why.** Do not silently drop it, and do not silently reshape it
into whatever was easy.

### Test implementation conventions

Each convention is stated as a property with its check (`CONVENTIONS.md` §8).

**Naming and linkage.** One test function per `EVAL-nnn`, named `test_eval_<id>_<short_description>`
(or your stack's equivalent). *Check:* from any failing test name, the protected requirement can be
found in one step, without a lookup.

**Assert the obligation, not the implementation.** Exercise the module through its public entry
point, not its internal helpers. *Check:* a refactor with no behaviour change requires no test change.

**The expected value comes from the source, never from the code under test.** If a requirement names
a threshold, a duration or a count, write that literal value into the test, taken from the
requirement. Never import it from the module being tested. Importing the code's own constant turns the
assertion into a tautology, so a wrong constant passes its own test. The same applies to any
expectation *computed* from the implementation's own data structures. *Check:* change the constant in
the implementation, and the suite must fail.

**Assert side effects, not just return values.** Where a requirement obliges a record to be written,
a field to be set, an alarm raised or an error raised, assert that too, and assert the **count** of
records created as well as their content. This catches silent no-ops and accidental duplicates.
*Check:* suppress the side effect in the implementation, and the suite must fail.

**Don't test the framework.** Asserting that the persistence layer persists a field tests the
persistence layer. Assert the behaviour the requirement demands, at the layer where this project's own
logic decides it.

**Don't mock the system under test.** Mock only genuinely external boundaries the project does not
own, such as given hardware interfaces or third-party services. Everything inside the module runs for
real, including its datastore, and runs against the technology a constraint mandates. A suite that
passes against a substituted datastore is not evidence when the datastore is itself required.

**Parametrize enumerable obligations.** Where a requirement enumerates categories, triggers or
profiles, parametrize over all of them rather than testing one representative. A requirement naming
six categories with one test covering one category is 17% covered while appearing green. *Check:*
remove any single member from the implementation's catalog, and the suite must fail.

**Each test is independent.** No ordering dependency, no shared mutable state, no reliance on data
another test created. *Check:* every test passes when run alone and in random order.

**Beware the test harness hiding the defect.** A test asserting *both* that an exception was raised
*and* that a side effect persisted is unreliable under a harness that wraps each test in a
transaction. The exception is caught *inside* that transaction, so the rollback the exception would
cause in production never reaches the assertion. The test passes *because of* the harness, not
because the behaviour is correct. This has been observed in practice: a set of cases asserting that a
blocked operation still wrote its audit record all passed while the record was rolled back in every
real caller. Where a requirement demands both refusal and a durable record, prove durability outside
the harness, with a test mode that really commits or a probe that commits and re-reads on a separate
connection. *This rule cannot be fully mechanized: it requires reasoning about what the harness does
differently from production.*

**Boundary cases sit exactly at the boundary.** A threshold test using a value comfortably past the
limit passes under both a correct and an incorrect reading of the rule, and so distinguishes nothing.
Write the case *at* the boundary and, where the requirement's wording leaves inclusivity ambiguous, one
on each side. *Check:* shift the implementation's threshold by the smallest unit, and the suite must
fail.

## Step 4 — Disclose what this pass does not cover

List what a reader might reasonably expect to be covered and is not: requirements whose triggers
depend on unbuilt modules, on external signals, or on access control that does not exist yet; rules
with no enforcement point yet; anything deferred.

## Step 5 — Push findings upstream (mandatory, not optional)

**An eval-set document is not a valid final home for an open item.** It is too granular to be read by
the builders of other modules, so an item that lives only here is invisible exactly to the people who
need it. Every out-of-scope disclosure and every genuine finding is transmitted before this skill is
complete:

1. **An unresolved question, a missing input or a decision someone must make** goes to the
   requirements document's open items as a `REQ-nnn`, via `modify-requirements-doc`, stating what is
   unknown, what it blocks and who must resolve it.
2. **Anything that blocks or affects another module** gets a "Blocked by / Affected by" reference in
   that module's roadmap entry, via `update-roadmap`, pointing to the `REQ-nnn`. Point, never restate.
3. **A defect in already-reviewed work** goes to `create-bug-log-entry`.

**State in the eval-set document where each item was transmitted**, so that a reader can verify the
transmission happened rather than trusting that it did.

## After drafting

1. Mark the eval set `status: draft` with `[PRELIMINARY]` marking. Cases derived from a
   still-preliminary requirement say so explicitly, since they will need re-checking if that
   requirement changes.
2. Run the suite and log the run via `create-eval-log-entry`. Log the session via
   `create-dev-log-entry`.
3. The eval set goes through `review-eval-set`, in a fresh session, before status can move to
   `reviewed`. Once reviewed it is part of the permanent regression suite, run on every change.
