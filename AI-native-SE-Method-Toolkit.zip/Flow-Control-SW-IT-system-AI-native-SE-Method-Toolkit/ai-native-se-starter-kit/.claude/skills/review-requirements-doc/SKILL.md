---
name: review-requirements-doc
description: Independently evaluate a requirements document — anchoring to its source in both directions, conformance to the INCOSE requirement-quality characteristics, and proposed rewrites — producing per-requirement findings and a set-level verdict. Use as the review gate any time requirements are drafted or modified, never to simply "check if a draft looks right."
---

You are the **independent reviewer, not the author.** Run this in a fresh session with no shared
context from whatever produced or last edited the document. **If you were part of that conversation,
stop and ask to be invoked fresh** ([`CONVENTIONS.md`](../../../CONVENTIONS.md) §7.3).

## Choosing the tactic — read this before anything else

A requirements document has two possible eval forms, and **using the wrong one produces findings that
are artifacts of the method rather than defects in the artifact** (§7.2).

| If | Then | Because |
|---|---|---|
| You hold a **separable source obligation rich enough to re-derive from**, such as a regulation, a standard, a contract, or a stakeholder specification written by someone else | **Regenerate-and-diff, then Passes B and C.** For the clauses in scope, derive the requirements independently, **write the derivation to `intermediary/` before opening the draft**, then diff, which covers Pass A | The high-value finding is an **absence**, and you cannot find a missing requirement by reading the ones that are present |
| The obligation is **not separable or not sufficient**: it is descriptive prose, it was written by the same authors in the same document, or it cannot support deriving the full set | **Conformance audit: Passes A, B and C below** | Re-derivation from an insufficient source produces thin output, and the "absences" it reports are artifacts of an underinformed derivation |

**Say which you chose and why, in the log.** Choosing regenerate-and-diff where the source cannot
support it is the failure this table exists to prevent.

**Independence under the conformance tactic comes from the rubric being external.** The INCOSE
characteristics were not written by the document's authors, are not derived from the document, and
are not produced by you.

## Before you start

1. Read `CONVENTIONS.md`: traceability (§2), sources (§3), status and marking (§4), logging (§6),
   review (§7).
2. **Pin the revision** you are reviewing (§7.4) and record it.
3. Read the source extractions in `sources/`, **including each "could not extract" block.** Anything
   that block names as lost and that bears on a requirement in scope is **declared unchecked**, and
   reported as an extraction defect to be fixed upstream (§3). Do not open the original to work
   around it.
4. Read the requirements document's own provenance block. Where requirement text is reproduced
   verbatim from a source, **defects in it belong to the source.** Report them as findings, not as
   transcription errors.

---

## Pass A — Anchoring: is every requirement found in the source, and every obligation in the requirements?

Check both directions, and **report them separately**.

**A1 · Forward: every requirement traces to something.** For each requirement, name the source
clause it rests on. Flag:

- a requirement resting on **nothing** in the source, which is unexplained scope;
- a requirement that **cites** a clause that does not say what is claimed, or that satisfies a
  narrower or broader obligation than the clause states;
- a requirement referencing a **constant, term or value that is never defined** anywhere. This is
  the cheapest high-value check in the pass and it is almost always productive;
- an ambiguity the draft **resolved silently**, without a `[PRELIMINARY — ambiguous]` flag.

**A2 · Backward: every obligation is covered.** For each obligation in the source (each interface,
each named function, each stated constraint), name the requirements that discharge it, and flag any
with none. **This is the absence check.** It is bounded by what the source actually states, so do not
invent obligations the source does not carry in order to report a gap.

**A3 · Internal consistency of the set.** Look for conflicting requirements, duplicates under
different IDs, terminology that shifts between entries, and a referenced ID that does not exist.

---

## Pass B — Conformance to the INCOSE requirement-quality characteristics

Apply the characteristics from the INCOSE *Guide to Writing Requirements*. **Per requirement:**

| | Characteristic | The question |
|---|---|---|
| C1 | **Necessary** | Does it define an essential capability, characteristic, constraint or quality factor, or could it be removed with nothing lost? |
| C2 | **Appropriate** | Is the level of detail right for the entity it refers to, rather than drifting down into design or up into intent? |
| C3 | **Unambiguous** | Can it be read in only one way by every intended audience? |
| C4 | **Complete** | Does it state the capability, conditions and constraints sufficiently, without needing information that is not there? |
| C5 | **Singular** | Does it state one capability, characteristic, constraint or quality, rather than several joined by *and*, *or*, a comma or a list? |
| C6 | **Feasible** | Is it realizable within cost, schedule, technical, legal, ethical and safety constraints at acceptable risk? |
| C7 | **Verifiable** | Can its satisfaction be established? **An unbound quantity, an undefined constant or an unmeasurable adjective makes it unverifiable**, and this is the characteristic most often failed |
| C8 | **Correct** | Is it a true statement of what is needed? |
| C9 | **Conforming** | Does it follow the document's own conventions: the agreed pattern, modal verb, units, identifier format? |

**And on the set as a whole:**

| | Characteristic | The question |
|---|---|---|
| C10 | **Complete** | Does the set stand alone (capabilities, constraints, conditions, interactions, standards, safety, quality factors) without requiring another set at this level? |
| C11 | **Consistent** | Are the requirements unique, free of conflicts, and uniform in terminology throughout? |
| C12 | **Feasible** | Is the set realizable as a whole within the entity's constraints at acceptable risk? |
| C13 | **Comprehensible** | Can a reader understand what is expected of the entity and how it relates to the wider system? |
| C14 | **Able to be validated** | Can it be shown, at acceptable risk, that satisfying the set achieves the actual need? |

**How to record it.** A verdict per requirement per characteristic is unreadable and nobody acts on
it. Record **only the failures**, each as: the ID, the characteristic, the specific words that fail
it, and why. Then give the **counts per characteristic** across the set, which shows a reader where
the document's weakness actually is.

**Do not soften a failure into a suggestion.** *"The bound is unspecified, so the requirement is not
verifiable"* is a finding. *"It might be clearer to specify the bound"* is not.

Also check **structure** (Tier 0, §7.1): ID format, status field, `[PRELIMINARY]` on unreviewed
content, and revision history present and non-destructive.

---

## Pass C — Refinement

For every C1–C9 failure, propose a **rewrite**, not a comment: one proposed requirement text,
carrying:

- the defect it fixes, named by characteristic;
- any value you had to invent, marked **`[ASSUMPTION]`** and listed for the owner to rule on;
- a note where the fix **cannot** be made without information nobody has. That is a question for the
  owner, and it goes to the open items rather than becoming a rewrite.

**Do not apply the rewrites.** Propose them, and `modify-requirements-doc` applies them. A reviewer
that edits the document destroys the evidence that the gate worked (§7.4).

---

## Recording the outcome — including when you find nothing

Log via `create-eval-log-entry`, to `logs/eval-log.md`:

- **date**, the document and pinned revision, and which IDs were in scope;
- **the tactic chosen and why**, per the table above;
- **the independence line**: fresh context, and where the derivation or rubric came from. If either
  is compromised, say so; the review still counts, at a lower weight;
- **Pass A**: requirements anchored to nothing, obligations with no requirement, undefined terms;
- **Pass B**: failure counts per characteristic, and the set-level verdicts C10–C14;
- **Pass C**: how many rewrites were proposed and how many are blocked on a question for the owner;
- **routing**: which findings go to `modify-requirements-doc` as fixes and which are open items for
  the owner (§7.4);
- **the checks you did not run, and why.** Anything declared unchecked at "Before you start" step 3
  **must** appear here, because an unnamed gap reads as a clean result;
- **what the pass cost**: elapsed time, tool calls, anything notable.

**A pass that found nothing material still gets logged** (§6). Flag to the owner which requirements
are **eligible** for `status: reviewed`. You do not set it.
