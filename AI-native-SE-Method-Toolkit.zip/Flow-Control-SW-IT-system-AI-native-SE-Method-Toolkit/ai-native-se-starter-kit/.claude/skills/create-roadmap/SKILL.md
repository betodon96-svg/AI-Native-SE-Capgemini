---
name: create-roadmap
description: Draft the initial roadmap — a falsifiable success definition for each milestone plus a Now/Next/Later placement of every module in the requirements and architecture. Use when no roadmap exists yet and the project needs a living plan distinct from the requirements (what and why), the architecture (how) and the dev log (what already happened).
---

You are drafting the **first version** of this project's roadmap. This skill is domain-agnostic. All
project-specific content comes from the repository's own documents.

## What a roadmap is for, and what it isn't

A roadmap answers *"where are we relative to shipping, and what is next?"*, a question none of the
other artifacts answer. It is not:

- the requirements document, which says what the system must do and why;
- the architecture, which says how the system is structured;
- the dev log, which is an append-only history of what already happened.

It is a **living status document** (Pattern B, [`CONVENTIONS.md`](../../../CONVENTIONS.md) §5),
edited in place as priorities shift, with every change recorded in a revision row. Use
**Now / Next / Later** buckets, not committed dates. A small team's schedule is fiction a few weeks
out, and a falsely precise date is worse than an honest bucket.

## Before you start

1. Read `CONVENTIONS.md`: status and marking (§4) and change control (§5). The roadmap carries a
   status field and a revision history like any artifact.
2. Read the requirements document in full, including its open items, for the module list, the
   `REQ-nnn` ranges each module owns, and the blockers.
3. Read the architecture for how modules depend on each other.
4. Check whether `roadmap/` already holds a roadmap. If it does, use `update-roadmap`. This skill is
   for the first draft only.

## Drafting

1. **Define what "done" means as a falsifiable target**, not a vibe. If the project has more than one
   meaningful milestone (for example a demonstration or pilot distinct from a full-obligation
   release), state each explicitly and distinctly. Do not collapse them into one fuzzy goal.
2. **Place every module in Now / Next / Later:**
   - **Now**: what is actively being built. Usually one module, perhaps two.
   - **Next**: modules with no blocking open item, buildable in a sensible order toward the nearest
     milestone.
   - **Later**: modules blocked on an open item (cite its `REQ-nnn`), or lower priority for the
     nearest milestone even if unblocked.
3. **Give each module its review state**: not started, eval set specified, implemented, pending
   review, or reviewed. These follow the module sequence in [`CLAUDE.md`](../../../CLAUDE.md). A
   module is never shown as done while its review loop is open.
4. **Cross-cutting requirements do not get their own bucket.** If a requirement group applies to every
   module as it is built (a security baseline, an audit-record obligation), say so explicitly, and
   note which requirements ride along with which modules, rather than placing it in a bucket as if it
   were a discrete phase.
5. **State non-goals and risks by reference, not duplication.** Point at the requirements document's
   deferred markers and open items, and at `DECISION_LOG.md`, rather than re-listing them here. A
   roadmap that duplicates another document's content will drift from it.
6. Mark `status: draft` and add a first revision-history row.

## Check before handing over

The roadmap has no source obligation to be re-derived from, so it gets no independent review. Its
check is **internal consistency**, done now:

- every `MODULE-x` in the architecture's component view appears exactly once;
- every "blocked by" cites an open `REQ-nnn` that exists in the requirements document;
- no Next module depends on a Later one.

## After drafting

Log the session via `create-dev-log-entry`. Tell the owner that this is a living document, to be
revisited with `update-roadmap` at the start of each work session or whenever a module changes state,
not a one-time artifact to approve and forget.
