---
name: modify-eval-set
description: Update existing eval cases (EVAL-nnn) following a requirement change, a defect that revealed a coverage gap, a review finding, or a correction to a previously wrong expected result. Use when eval cases already exist and need to change, never for a requirement's first cases.
---

You are changing **existing** eval cases. To specify a requirement's first cases, use
`create-eval-set`.

## Before you start

1. Read [`CONVENTIONS.md`](../../../CONVENTIONS.md): change control (§5) and logging (§6). An eval set
   is a Pattern A register: each case keeps its own revision history.
2. Identify exactly which `EVAL-nnn(a/b/…)` cases are affected, and why. The reasons are: a linked
   `REQ-nnn` changed (cite its revision); a defect revealed missing coverage (cite the
   `logs/bug-change-log.md` entry); a review found a gap or a vacuous case (cite the
   `logs/eval-log.md` entry); or a case's expected result was itself wrong (cite how that was
   discovered).
3. Re-read `create-eval-set`'s test implementation conventions **from the file**, now, before
   changing any test. Do not rely on recollection of them (§8).

## Making the change

1. Append a revision entry to each affected case rather than silently editing its expected result:
   date, author, what changed, and why.
2. **If a defect revealed the gap, add a new case reproducing it** rather than only fixing an existing
   one, so the regression suite would have caught it. *Check:* the new case fails against the
   pre-fix implementation.
3. Reset `status` to `draft` and reapply `[PRELIMINARY]` on any case whose expected behaviour
   changed, because it needs to clear review again.
4. Keep the numbering intact. A new case for an existing requirement takes the next unused letter
   suffix, and existing cases are never renumbered.
5. **Keep the specification table and the test code in sync.** If the expected behaviour changed,
   the documented Input and Expected columns and the test body change together. A specification table
   describing behaviour the tests no longer implement is worse than no table.

## Push findings upstream (mandatory, not optional)

The rule in `create-eval-set` step 5 applies to every change made here. **An eval-set document is not
a valid final home for an open item.** If this change surfaced or altered an unresolved question, a
missing input or a decision someone must make, write it to the requirements open items via
`modify-requirements-doc`, and reference that ID from the affected module's roadmap entry via
`update-roadmap`. Point to the ID and never restate its text. If a previously transmitted item is now
resolved, close it at its source in the requirements document, not only here.

State in the eval-set document where each item was transmitted.

## After the change

1. Run the suite and log the run via `create-eval-log-entry`.
2. If the trigger was a defect, make sure a `create-bug-log-entry` exists for it, cross-linked by ID.
3. Flag that the modified or added cases need another `review-eval-set` pass, scoped to the change,
   before they can move past `draft`.
