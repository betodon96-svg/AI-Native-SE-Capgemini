---
name: modify-use-case-doc
description: Apply a change to one or more existing use cases — following a requirement change, a corrected understanding of a workflow, a stakeholder-driven adjustment, or a review finding. Use when the use-case document already exists, never for the first draft.
---

You are changing an **existing** use-case document. If none exists, use `create-use-case-doc`.

## Before you start

1. Read [`CONVENTIONS.md`](../../../CONVENTIONS.md): change control (§5) and logging (§6). The
   use-case document is a Pattern A register, so a use case is never silently edited away or
   overwritten. Every change is a new, dated revision with rationale, appended to its history.
2. Identify exactly which `UC-nnn` IDs are affected, and which `REQ-nnn` IDs they link to. If the
   trigger is a requirements change, cite the `REQ-nnn` revision that drove it. If it is a review
   finding, cite the `logs/eval-log.md` entry.

## Making the change

1. Append a revision entry: date, author, what changed, and why, citing the trigger by ID, and by
   commit SHA if it traces to an implementation change.
2. If the change alters the flow's meaning rather than its wording, reset `status` to `draft` and
   reapply `[PRELIMINARY]`, because it needs to clear review again.
3. If the change reveals a missing or wrong requirement, **do not fix it here.** Transmit it via
   `modify-requirements-doc`.
4. Do not bundle unrelated fixes into this change. Log those separately.
5. If the architecture's sequence views depict this flow, note that they need a follow-up via
   `modify-architecture-doc`. This skill does not make that change.

## After the change

1. If the trigger was a defect, record it via `create-bug-log-entry`.
2. Flag that the modified use case needs another `review-use-case-doc` pass, scoped to the change,
   before its status can advance past `draft`, unless it was a pure clarification.
