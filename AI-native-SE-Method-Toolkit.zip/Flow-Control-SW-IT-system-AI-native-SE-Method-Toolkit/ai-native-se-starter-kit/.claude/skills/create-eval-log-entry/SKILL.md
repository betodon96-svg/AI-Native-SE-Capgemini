---
name: create-eval-log-entry
description: Append an entry to the eval log recording the outcome of a check that actually ran — a deterministic test-suite execution, or an independent review pass on any artifact — including passes that found nothing. Use any time either kind of check runs and its result needs a permanent record.
---

You are recording a check that was **actually run**. This skill logs after the fact; it does not
perform the check. For that, use `create-eval-set` or one of the `review-…` skills.

Review of a knowledge artifact *is* that artifact's eval
([`CONVENTIONS.md`](../../../CONVENTIONS.md) §7.1), so test runs and review passes share one log. An
eval that has never failed is indistinguishable from one that *cannot* fail without this record, and
that is why the log exists.

## Before you start

Read `CONVENTIONS.md`: traceability (§2) and logging (§6). Entries reference artifacts by ID and code
by commit SHA, never by pasting content.

## Writing the entry

Append to `logs/eval-log.md`, **newest first**, never editing or removing a prior entry. A correction
is a new entry that references the old one. Each entry records:

- **Date, and the kind of check**: a test-suite execution, or a review pass. For a review, name the
  skill and the **tactic** (regenerate-and-diff or conformance audit, §7.2).
- **The target**: the artifact and IDs (`REQ-nnn`, `UC-nnn`, `EVAL-nnn`, `MODULE-x`), and **the
  pinned revision** (commit SHA).
- **For a test-suite run**: pass, fail or not-run per case; the technology it ran against; and a
  pointer to the full output if it lives elsewhere. Do not paste large logs inline.
- **For a review pass**:
  - **the independence line**: fresh context, and where the derivation or rubric came from. If
    either is compromised, say so;
  - the findings, each concrete (what was expected, what the artifact says, why they differ) and each
    **routed**: fix here via which `modify-…` skill, or upstream to which open item. Otherwise write
    **"no material findings"** explicitly;
  - the mutations run and their outcomes, where applicable.
- **The checks not run, and why.** An unnamed gap reads as a clean result.
- **What it cost**: elapsed time, tokens or tool calls where available, and errors.
- **The status recommendation**, for example "eligible for `reviewed`" or "needs rework, see
  findings". This entry records the recommendation. The status change itself happens in the target
  artifact, by the owner.
- **Whether this is a re-review**, and of which earlier entry. The loop is closed only by a re-review
  that returns nothing material (§7.4).
