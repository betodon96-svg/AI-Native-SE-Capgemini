---
name: create-architecture-doc
description: Draft the initial architecture document — system design plus diagrams rendered as Mermaid — derived from the requirements (and use cases, where they exist), with views selected to fit the system's class rather than assumed, and a requirement-to-component coverage matrix as a deliverable. Use when no architecture document exists yet.
---

You are drafting the **first version** of this project's architecture document. This skill is
domain-agnostic. All project-specific content comes from the repository's own documents.

## Step 0 — Four gates. Stop at any that does not pass

**Do not start drafting until all four are settled.** Skipping any of them produces an architecture
that looks finished and is wrong in a way review will not easily catch.

### Gate 1 · What class of system is this, and therefore which views?

**The dominant architectural view is whatever the requirements are organized around.** Read the
requirements document's structure before choosing a notation. If it is organized by operating mode,
the mode machine *is* the architecture, and a container diagram is a formality.

| System class | Signals in the requirements | Primary views |
|---|---|---|
| **Information system** | Deployable pieces, users and roles, data stores, request/response flows | **C4**: Context → Container → Component. Sequence per significant use case. Class/ER for the data model |
| **Embedded / cyber-physical** | Operating modes and transitions, sensors and actuators, physical quantities, timing and tolerance constants, safety interlocks | **Context** (system, actors, physical boundary) → **mode/state machine** → **component and hardware boundary** → sequence for the safety-critical paths → data model only where state is persisted |
| **Mixed** | Both sets of signals | Both, and say which is primary |

**Record the classification and the views chosen in the document's opening section.** A reader must
be able to see that the view set was a decision, not a default. If the class is genuinely unclear,
that is a question for the owner, not a coin toss.

### Gate 2 · Are the constraints real?

Read the non-negotiable constraints in [`CLAUDE.md`](../../../CLAUDE.md). **If they are still
placeholder text, stop and say so.** An architecture checked against placeholders has not been
checked. An architecture that violates a stated constraint is wrong regardless of how clean it looks.

### Gate 3 · Is the scope rulable in one pass?

Count the requirements. If the set is larger than one pass can give a component owner to, **stop and
ask the owner to scope it**: one subsystem, one mode subtree, one function. Do not silently cover part
of the set and present it as the architecture. A partial architecture presented as whole is worse
than none, because the gaps look like decisions.

### Gate 4 · Is your input complete enough to derive from?

Read the requirements document's **provenance block** and the **"could not extract" blocks** of the
source extractions it rests on. If your architecture would depend on something named there, such as
a flattened table, a figure or a diagram:

**Stop, and send it back to be fixed in the extraction. Do not go and read the original yourself**
([`CONVENTIONS.md`](../../../CONVENTIONS.md) §3). This skill derives from the requirements, not from
the source; reading the source here would create a second, divergent reading of it. And a lossy
intermediate is one defect in one place, which should be fixed once, upstream, rather than worked
around by every consumer.

Where the gap cannot be closed in time, **declare the dependency unchecked in the document** and
proceed. Declaring it is acceptable. Silently deriving from a known-lossy input is not.

## Before you start

1. Read `CONVENTIONS.md`: traceability (§2), status and marking (§4), change control (§5), and **§9,
   the diagramming standard**.
2. Read the requirements document **in full, including its open items**. **Architecture derives from
   the requirements, not from the source obligations directly.** The requirements have already turned
   source clauses into testable obligations, and redoing that derivation here would create a second,
   divergent reading of the source.
3. Read the use-case document **if one exists**. **If it does not, do not invent use cases.** Derive
   the behavioural views from the structure the requirements already carry (modes, transitions,
   triggering conditions), and record in the document that no use-case document existed.
4. Identify anything described as a **given external interface**: existing hardware, an upstream
   system, a third-party service. **Do not design it.** Model it as a boundary the system talks to.
   Where the requirements give a typed data contract for it, use that contract verbatim. Where they
   do not, **ask.** Do not invent one.
5. Check whether `architecture/` already holds a document. If it does, use `modify-architecture-doc`.

## Drafting

1. **Opening section**: a provenance block (§2), the system classification from Gate 1, the views
   chosen and why, the scope ruled at Gate 3, and anything declared unchecked at Gate 4.
2. **Context view**: the system as one box, its actors and roles, and every external system or
   physical boundary it interacts with. It must be understandable by someone with no technical
   background.
3. **The primary structural or behavioural views for the class**, per Gate 1. For an embedded system
   that means the **mode machine first**: every mode, every transition, and the condition on each,
   because that is what the requirements are about.
4. **Component view**: the internal parts and their responsibilities. **Name each to match a
   `MODULE-x` ID.** A component here, a module in the eval set and a directory in `implementation/`
   should be recognizably the same thing (§2).
5. **Sequence views** for the paths where ordering carries risk: an interlock, an alarm response, a
   command that changes an output, a record that must be durable even when an operation fails. Do not
   draw one per requirement.
6. **Data model**, only where state is persisted or exchanged, with entities named from the
   vocabulary the requirements already use. **Do not invent a new name for a concept that already has
   one.**
7. **The coverage matrix is a deliverable, not a check.** Emit a table mapping **every requirement ID
   in scope** to the component or components responsible for it, using **the requirement document's
   own ID format**. Then state explicitly:
   - requirements with **no owning component**, which are gaps;
   - components tracing to **no requirement**, which is unexplained scope;
   - requirements whose owner satisfies a **weaker version** than the requirement states.

   **Record these. Do not quietly resolve them.** They are the most valuable output of this skill.
8. For every design decision with real alternatives (a datastore, a protocol, synchronous versus
   asynchronous, where a safety check sits), **state the decision and a one-line rationale.** Do not
   silently pick one and hide the tradeoff. Flag anything genuinely undetermined as `[PRELIMINARY]`.
9. **Point, never restate.** Open items belong to the requirements document. Reference them by ID;
   do not copy them into an open-items section here (§5).
10. **Render every diagram** before considering it done (§9). A diagram that looks right by eye can
    still fail to parse, and both failure modes named in §9 are invisible in the source text.
11. Mark the document and each section per §4, with `status: draft`, version `v1`, and a first
    revision-history entry. Include an empty **"Changed since v(n−1)"** section for the next version
    to fill (§5, Pattern B).

## After drafting

1. Findings that are really requirements problems (an obligation no component can own, an ambiguity
   you had to guess at) go **upstream** as open items via `modify-requirements-doc`. Do not resolve
   them in the architecture.
2. Log the session via `create-dev-log-entry`: the classification and views chosen, the scope ruled,
   **the coverage numbers** (requirements in scope, owned, unowned, components without a requirement),
   which diagrams you rendered and whether any failed first, anything declared unchecked, and what the
   run cost.
3. This document goes through `review-architecture-doc` in a fresh session before status advances
   past `draft`. **Do not mark anything `reviewed` or `approved` yourself.**
