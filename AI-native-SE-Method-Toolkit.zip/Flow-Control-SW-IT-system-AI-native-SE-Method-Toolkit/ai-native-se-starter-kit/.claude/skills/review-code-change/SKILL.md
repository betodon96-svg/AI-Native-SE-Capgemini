---
name: review-code-change
description: Independently validate an implementation change against the requirements and architecture (and the source extraction where a requirement is ambiguous), using regenerate-and-diff, by actually re-running the tests, and by mutating the code to confirm the suite notices — before that code can be considered reviewed. Use as the review gate for implementation code.
---

You are the **independent reviewer** of a code change, not its author. Run this in a fresh session
with no shared context from whichever session wrote the code. If you were part of that conversation,
ask to be invoked fresh ([`CONVENTIONS.md`](../../../CONVENTIONS.md) §7.3). Code is not exempt from
independent review because it is not prose.

There is no `create-code` or `modify-code` counterpart to this skill. Writing code is ordinary
development, tracked by the roadmap. Review is the one code-adjacent step that needs its own skill,
because it is where independent derivation has to be deliberately imported into an activity that does
not impose it on itself.

## Method: regenerate-and-diff, not critique-in-place, plus actually running it

Do not start by reading the code and asking "does this look right?" That anchors you to the author's
own reasoning. Instead:

1. Read `CONVENTIONS.md` (§2, §4, §7) and the non-negotiable constraints in
   [`CLAUDE.md`](../../../CLAUDE.md).
2. **Pin the revision** you are reviewing (§7.4): the exact commit, plus a file-existence check that
   proves you are at it. Record both.
3. Read the architecture document for how this module fits the system: its component boundary, what
   it depends on, and what depends on it.
4. Read the `REQ-nnn` entries the code claims to implement, **directly from the requirements
   document, not from the code's own comments about what it does.** Where a requirement's wording is
   ambiguous, or where the code itself flags an interpretive judgement (a comment explaining why it
   read a phrase one way), read the cited `SRC-x.y` extraction directly too.
5. **Before reading the code**, write your own expectation to `intermediary/`: given these
   requirements, what should this code do? Cover inputs, outputs, edge cases, boundaries, and side
   effects (records, alarms, state changes).
6. **Now** read the implementation (data model, logic, entry points, configuration, and its tests),
   and diff against your expectation. Check specifically for:
   - **Logic that does not satisfy the requirement it claims to**, including subtle drift. Examples
     are a check that compares the wrong value, or one that is unreachable or vacuous although it
     looks like the rule.
   - **Missing edge cases** the requirement implies but the code does not handle.
   - **Silent, undisclosed interpretive assumptions.** A disclosed one (a comment explaining and
     justifying a reading) is fine if the reasoning holds. An undisclosed one is a finding whether or
     not it happens to be correct.
   - **Magic numbers**: hardcoded values that should be named constants traceable to a requirement
     or source clause, such as a threshold, a retention period or a field length.
   - **Constraint violations**: anything that contradicts a constraint in `CLAUDE.md`, such as runtime
     model inference where it is ruled out, code that redesigns rather than consumes a given external
     interface, or a substitute for a mandated technology.
   - **`MODULE-x` boundary consistency** with the architecture's component view: does this code live
     where the architecture says, and stay inside its own boundary?
   - **Not-yet-checked collapsed into checked-and-fine**: a boolean verification field whose default
     reads as passing when no check has run (`CONVENTIONS.md` §4).
   - **Eval-set coverage**: does `evals/eval-sets/` have an `EVAL-nnn` case for each `REQ-nnn` this
     code claims, and does each test actually exercise the behaviour it is named for?
7. **Run the tests yourself.** Do not take a prior session's "all passing" claim on faith. Re-run the
   suite and confirm the result. If a constraint mandates a technology (a particular datastore, a
   platform), confirm the tests ran against it and not against a substitute that is faster or easier
   to set up.
8. **Mutate the code and confirm the suite notices.** Reading tells you whether the code looks right;
   mutation tells you whether anything would catch it being wrong. In practice, defects in reviewed
   code are found by mutation or by independent derivation far more than by reading. Follow
   `review-eval-set`'s mutation guidance (method step 7) for what to target and why *you*, not the
   author, choose the mutations. Record which mutations you ran and their outcomes.

## Recording the outcome — including when you find nothing

- **Report, do not repair.** List discrepancies concretely: the requirement, what you independently
  expected, what the code does, and why they differ. Do not fix the code yourself. The fix goes
  through ordinary development and then back through this review, scoped to the change.
- **Split the findings** (§7.4). Defects to be fixed here go to the developer. Open questions,
  cross-module blockers and requirement problems go upstream via `modify-requirements-doc`, and are
  referenced from the roadmap. Say which is which.
- Log the pass via `create-eval-log-entry`: the pinned commit and module; the independence line;
  confirmation that you re-ran the tests, and against what; the mutations and their outcomes; the
  findings or **explicitly that there were none**; the checks not run; and the cost.
- If there are no material discrepancies and the tests genuinely pass against the real stack, flag
  to the owner that the module is **eligible** to leave "pending review" on the roadmap. You do not
  set that status.
