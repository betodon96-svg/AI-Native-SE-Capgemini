---
name: review-eval-set
description: Independently validate an eval set (EVAL-nnn cases and their implemented tests) against the requirements, using regenerate-and-diff, by actually running the suite, and by curating mutations the author did not choose — before the eval set can be considered reviewed. Use as the review gate for eval sets.
---

You are the **independent reviewer** of an eval set, not its author. Run this in a fresh session with
no shared context from whichever session specified or implemented the cases. If you were part of that
conversation, ask to be invoked fresh ([`CONVENTIONS.md`](../../../CONVENTIONS.md) §7.3).

A mandated review with no means of running it is worse than an honest absence, because it reads as a
control that exists. This skill is that means for eval sets.

## Why regenerate-first matters more here than anywhere else

The highest-value defect in an eval set is a **missing case**: a requirement clause with no test at
all. You cannot find an absent test by reading the tests that are present, so critique-in-place is
structurally blind to it. Deriving the expected case list independently, before seeing the draft, is
the only method that surfaces holes rather than just flaws.

It is also the failure mode most likely to be present. An eval set written after its implementation
tends to cover what the code does, which is not the same as what the requirement demands.

## Method

1. Read `CONVENTIONS.md` (§2, §4, §7) and the constraints in [`CLAUDE.md`](../../../CLAUDE.md).
2. **Pin the revision** you are reviewing (§7.4) and record it.
3. Read the `REQ-nnn` entries this eval set claims to cover, **directly from the requirements
   document**, not from the eval-set document's own summary of them. Where a requirement is
   ambiguous, read the `SRC-x.y` extraction it cites.
4. **Before reading the eval set at all**, write your own expected case list to `intermediary/`. For
   each requirement, decompose it into distinct clauses. For each clause, state what cases would
   establish it, with concrete inputs and expected outputs. Identify every boundary the requirement
   implies, and what a vacuous or false-passing test of it would look like.
5. **Now** read the eval-set document and its implemented tests, and diff against your derivation.
   Report on each of these:
   - **Missing coverage**: a requirement clause with no case. State the clause and the case that
     should exist. This is the finding class this method exists to catch, so look for it first and
     hardest.
   - **Boundary avoidance**: a threshold, duration or count tested comfortably either side of the
     boundary but not *at* it. An off-boundary test cannot distinguish two readings that differ only
     at the boundary, so it provides false assurance.
   - **Self-referential expectations**: an expected value imported from, or computed from, the code
     under test. Such an assertion cannot fail for any implementation (§7.3).
   - **Vacuous or trivially passing tests**: a test that executes the code path without constraining
     its behaviour. **Check especially any case asserting both that an exception was raised and that
     a side effect persisted.** A transactional test harness can make such a case pass because of the
     harness (see `create-eval-set`'s conventions). Prove such a case outside the harness before
     believing it.
   - **Tests asserting the implementation rather than the requirement**: a case that would need
     rewriting after a refactor with no behaviour change is testing structure, not obligation.
   - **Spec/test drift**: the specification table says one thing and the test body does another.
     Check the actual test bodies against the documented Input and Expected columns. Do not assume
     they match because the names line up.
   - **Absence and null handling**: where the requirement distinguishes "checked and fine" from "not
     checkable", confirm that a case actually establishes the distinction.
   - **Undisclosed scope gaps**: something a reader would reasonably expect covered, omitted without
     appearing in the document's out-of-scope section.
   - **Upstream transmission**: `create-eval-set` step 5 requires every out-of-scope item and finding
     to be written to the requirements open items and referenced from the roadmap. **Verify that this
     actually happened by opening those documents.** Do not take the eval-set document's claim on
     faith (§7.4). An item disclosed only in the eval set is a finding.
6. **Run the suite yourself.** Do not take a prior session's "all passing" claim on faith. Confirm
   the result, and confirm it ran against the technology a constraint mandates rather than a faster
   substitute. A suite that passes because it never reached the real datastore is not evidence.
7. **Curate the mutation set. It is a deliverable of the review, not a self-check.**

   Deliberately break behaviours the suite claims to protect (locally, never committed), and confirm
   that the named case actually fails. A regression suite nobody has ever seen fail is an untested
   instrument.

   **You choose the mutations, not the author** (§7.3). An author picking their own mutation tends to
   pick one that flatters their own tests. This has been observed in practice: an author's chosen
   break happened to fail a *hardcoded* case, so they concluded the parametrized case beside it was
   sound, while a privilege-escalation defect passed that parametrized case green. Self-selected
   mutation reproduces the blind spot it exists to expose.

   Target, in this order:
   - **Values the source states**: thresholds, minimums, durations, counts. Change each to a nearby
     wrong value, and something must fail. A boundary tested from only one side survives this and
     needs pinning from both.
   - **Membership of a mandated catalog**: remove entries one at a time. Removing any single member
     must fail something. In practice, suites that looked complete have tolerated the removal of most
     of a catalog's members.
   - **Each guard or denial**: make it pass unconditionally. An access rule that fails open under
     mutation is a rule that is not there.
   - **Each mandated side effect**: suppress the record write, the alarm, the state change.

   Record which mutations you ran and their outcomes, so the set accumulates into a reusable curated
   suite instead of being re-derived every review. Automated whole-codebase mutation testing is a
   reasonable later goal. A reviewer-chosen set is affordable now, and it is already independent.

## Recording the outcome — including when you find nothing

- **Report, do not repair.** List discrepancies concretely: the requirement clause, the case you
  independently expected, what the draft actually contains, and why they differ. Route fixes through
  `modify-eval-set`, and route upstream items through `modify-requirements-doc`. Say which is which.
- Log the pass via `create-eval-log-entry`: the pinned revision; the eval set reviewed; the
  independence line (fresh context, expected case list written first); that you re-ran the suite and
  against what; **each mutation and its outcome**; the findings or **explicitly that there were
  none**; the checks not run; and the cost.
- If there are no material discrepancies and the suite genuinely passes against the real stack, flag
  to the owner that the eval set is **eligible** for `status: reviewed`. You do not set it.
