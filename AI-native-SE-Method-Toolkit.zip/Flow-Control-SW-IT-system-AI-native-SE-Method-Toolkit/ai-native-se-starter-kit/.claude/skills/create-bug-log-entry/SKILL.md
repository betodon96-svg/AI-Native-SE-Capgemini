---
name: create-bug-log-entry
description: Append an entry to the bug/change log recording a defect found (in the implementation, in an artifact, in an extraction, or in a skill) or a change decision about an artifact (a scope cut, a stakeholder compromise) not already captured by that artifact's own revision history. Use whenever a defect is found or such a change decision is made.
---

Read [`CONVENTIONS.md`](../../../CONVENTIONS.md) §6 (logging and rationale) before writing. The format
below follows it.

## Writing the entry

Append to `logs/bug-change-log.md`, **newest first**, never editing or removing a prior entry. A
correction to an earlier entry is a new entry that references it. Each entry records:

- **Date and a short title.**
- **What**: the defect (what broke, under what conditions) or the change decision (what was decided).
- **Why, and how it was found**: the review pass, test run, mutation or reading that surfaced it,
  citing the `logs/eval-log.md` entry where there is one, or what triggered the decision. **How a
  defect was found is evidence about the method**, so record it even when it seems incidental.
- **Root cause**, where known. If the defect traces to a corrected intermediate (a source extraction,
  an earlier artifact), name every other conclusion drawn from that intermediate. Each is stale until
  re-derived (§3).
- **What it affects**: every ID touched (`SRC-x.y`, `REQ-nnn`, `UC-nnn`, `EVAL-nnn`, `MODULE-x`) and
  the commit SHAs that fixed it. Reference rather than duplicate.
- **Status**: open, fixed or decided. If fixed, say how it was verified (for example, "new `EVAL-014c`
  reproduces it, fails before the fix, passes after").

The correction itself happens through the relevant `modify-…` skill. This skill only records the
entry, cross-linked to whatever fix results. A ruling that settles a question, rather than a change to
an artifact, belongs in `DECISION_LOG.md` instead.
