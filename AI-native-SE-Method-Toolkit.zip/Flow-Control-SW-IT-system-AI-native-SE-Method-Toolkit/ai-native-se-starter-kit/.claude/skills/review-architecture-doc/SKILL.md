---
name: review-architecture-doc
description: Independently validate a drafted or modified architecture document against the requirements, use cases and stated constraints, using regenerate-and-diff rather than critique-in-place, and verify its claims about any built implementation, before it can move from draft to reviewed. Use as the review gate any time the architecture document is drafted or modified.
---

You are the **independent reviewer, not the author.** Run this in a fresh session with no shared
context from whichever session drafted or modified the document. **If you were part of that
conversation, stop and ask to be invoked fresh** ([`CONVENTIONS.md`](../../../CONVENTIONS.md) §7.3).

## Method: regenerate-and-diff, not critique-in-place

**Why this document gets re-derivation.** The tactic depends on one question (§7.2): **do you hold a
separable obligation rich enough to re-derive the artifact from?** For an architecture you normally
do. The requirements document is a separate artifact, written at a different time, and it states
enough to determine what components must exist. So re-derivation works, and it finds absences. If the
requirements are too thin to determine the design, say so in the log. A re-derivation the input
cannot support produces findings that are artifacts of the derivation rather than defects in the
document.

Do not begin by reading the draft and asking whether it looks reasonable. That anchors you to the
draft's own design choices.

**Why deriving first is not ceremony here:** the highest-value defect in an architecture is a
**missing** component or an unowned requirement, and **you cannot find an absent component by reading
the components that are present.** Deriving your own view first is the only approach that surfaces
gaps rather than only flaws. Everything else below is secondary to it.

1. Read `CONVENTIONS.md`: §2 traceability, §4 status, §5 change control, §9 diagramming.
2. **Pin the revision** you are reviewing (§7.4) and record it.
3. Read the requirements document, the use-case document if one exists, and **the constraints in
   [`CLAUDE.md`](../../../CLAUDE.md)**, independently of the drafted architecture.
4. **Before reading the draft, sketch your own view and write it to `intermediary/`.** State the
   system class and the views it calls for, what components a design satisfying these requirements
   and constraints would need, which requirement each would own, and how they would interact to
   support the use cases or mode transitions.
5. **Now** read the actual document and its diagrams, and diff against your sketch:
   - **A requirement with no component responsible for it** is a gap. **A component that traces to no
     requirement** is unexplained scope. Check the document's coverage matrix against your own; do
     not take it on faith.
   - **Requirements the architecture silently weakened.** A component that satisfies a *weaker*
     version of a requirement than the requirement states is the hardest defect in this list to see,
     because the component looks present and the trace looks satisfied. Check what the requirement
     demands against what the component is specified to do, not whether a link exists.
   - **A view set that does not fit the system class**, for example a container diagram standing in
     for a mode machine the requirements are organized around.
   - **A violation of a stated constraint.**
   - **Scope creep into a given external interface**, which should be treated as a boundary and not
     redesigned.
   - **Diagram / prose drift**: does every diagram match what the prose says, and does component
     naming match the `MODULE-x` IDs used elsewhere?
   - **Syntax.** Actually render every diagram; do not eyeball it. Check the pitfalls in §9
     specifically, since both parse without any visible sign of a problem in the source.
   - **Audience violation**: does a stakeholder-facing view leak implementation detail? Is
     developer-facing detail missing where it belongs?
   - **Undisclosed assumptions**: a decision presented as settled that the requirements did not
     determine, which should have been `[PRELIMINARY]`.

## Verify the document's claims about the implementation — do not take them on faith

Where modules have actually been built, an architecture document stops being a derivation from
requirements and starts making **falsifiable claims about a codebase.** Check them against
`implementation/` directly:

- every entity the data model claims exists: does it, with the stated relationships and
  cardinalities?
- every constraint the document asserts is satisfied: **confirm by looking, not by reading the
  assertion**;
- every sequence or state view covering a built module: does the code do that, in that order, with
  those side effects? **Diagrams drift from implementations faster than prose does**, and a wrong
  diagram actively misleads where a missing one merely omits.

**The document's own account of what is true is the thing under review, not evidence for it.**

## Check the Pattern B obligations

If this is a revision rather than a first draft (§5):

- Is there a **"Changed since v(n−1)"** section, and does it record not only what changed but **what
  was checked and found still valid**? That second part is the whole point of the pattern and the one
  thing a git diff cannot supply.
- **Is that "still valid" list honest? Spot-check at least two of its claims.** A list asserting that
  sections were verified, written by the same author who changed the document, is exactly the kind of
  self-certification this gate exists to distrust.
- Are things the author could not verify **named explicitly**, rather than left silent?
- If the trigger was a corrected requirement or extraction, were **all** conclusions drawn from the
  uncorrected version re-derived, or only the one that prompted the change (§3)?

## Hunt for restated content

Any section duplicating content owned by another artifact (open items owned by the requirements
document, module status owned by the roadmap, requirement text owned by a `REQ-nnn`) **is a finding
even when the duplicate is currently accurate**, because the copy is what goes stale and nothing keeps
it correct (§5).

## Report, do not repair

List findings concretely: what you derived, what the draft says, and which diagram or section it is
in. **Do not silently redraw diagrams yourself.** Route the fix through `modify-architecture-doc`.

**Split the findings and transmit upstream** (§7.4). A finding that is really a requirements problem,
such as an obligation no component can own or an ambiguity the architecture had to guess at, belongs
in the requirements document's open items via `modify-requirements-doc`, with a dossier in
`open-questions/` if it needs more than a few lines. An architecture-only finding stays here. **Say
which is which** rather than leaving the routing to whoever reads the log.

## Recording the outcome — including when you find nothing

Log via `create-eval-log-entry`, to `logs/eval-log.md`: date; the pinned revision; which sections and
diagrams were checked; **the independence line** (fresh context, sketch written to `intermediary/`
before the draft was opened, and if either is untrue, say so); which implementation claims you
verified against `implementation/`; the findings and their routing, or **explicitly that there were
none**; **the checks you did not run and why**; and what the pass cost.

**A pass that found nothing material still gets logged** (§6). If your sketch matched the draft, flag
to the owner that the document is **eligible** for `status: reviewed`. You do not set it.
